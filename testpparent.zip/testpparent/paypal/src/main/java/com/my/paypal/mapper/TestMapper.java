package com.my.paypal.mapper;

import java.util.List;

public interface TestMapper {

	List<Test> getTest();
}
