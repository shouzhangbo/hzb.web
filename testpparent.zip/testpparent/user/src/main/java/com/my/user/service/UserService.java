package com.my.user.service;

import com.my.user.mode.User;

public interface UserService {

	public String test(User user);
}
