package com.my.test.mapper;

import java.util.List;

public interface TestMapper {

	List<Test> getTest();
}
