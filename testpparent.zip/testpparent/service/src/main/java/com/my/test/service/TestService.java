package com.my.test.service;

public interface TestService {
 public String getTest(String name);
}
